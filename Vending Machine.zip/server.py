import socket
import csv

HOST = '127.0.0.1'
PORT = 4000

# Create a server socket
socket1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind host and a port with a specific socket
socket1.bind((HOST, PORT))

# Listen for a connection from the client
socket1.listen(1)
#  Accept requests from a client socket, keeps waiting for incoming connections
print("Waiting for connection")
Connection, (host, port) = socket1.accept()

print(f'Received connection from {host} ({port})\n')
print(f'Connection Established , Connected from: {host}')


file = open("Stock.csv", "r", encoding='utf-8-sig')     # opening csv file as read mode
content = csv.reader(file)  # reading the file using csv reader and assigning it to a variable
next(content)   # skip the header
for row in content:     # read each row as a list
    string = "@".join(row)      # joining each row of data as a single string
    print(string)
    Connection.send(bytes(string, "utf-8"))  # Sending csv file as a single word to the server


# Receive coca data from client
coca_socket = Connection.recv(1024)
coca_socket = (coca_socket.decode("utf-8")).rsplit("@")
print(coca_socket)

# Receive sprite data from client
sprite_socket = Connection.recv(1024)
sprite_socket = (sprite_socket.decode("utf-8")).rsplit("@")
print(sprite_socket)

# Receive pepsi data from client
pepsi_socket = Connection.recv(1024)
pepsi_socket = (pepsi_socket.decode("utf-8")).rsplit("@")
print(pepsi_socket)

# Receive fanta data from client
fanta_socket = Connection.recv(1024)
fanta_socket = (fanta_socket.decode("utf-8")).rsplit("@")
print(fanta_socket)

# Receive fantaCherry data from client
fantaCherry_socket = Connection.recv(1024)
fantaCherry_socket = (fantaCherry_socket.decode("utf-8")).rsplit("@")
print(fantaCherry_socket)

# Receive pepper data from client
pepper_socket = Connection.recv(1024)
pepper_socket = (pepper_socket.decode("utf-8")).rsplit("@")
print(pepper_socket)

#  Close the connection
Connection.close()
