
# Importing Modules
import datetime
import socket
from tkinter import *
from tkinter import Label, messagebox
from PIL import Image, ImageTk
import matplotlib.pyplot as plt
import pandas as pd
import pygame


# socket part
HOST = '127.0.0.1'
PORT = 4000

# Create a server socket
socket2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#  Listen for a connection from a server and accepted
socket2.connect((HOST, PORT))

#  Receiving coca data from the server
coca_socket = socket2.recv(1024)
coca_socket = (coca_socket.decode("utf-8")).rsplit("@")
print(coca_socket)

# Receiving sprite data from client
sprite_socket = socket2.recv(1024)
sprite_socket = (sprite_socket.decode("utf-8")).rsplit("@")
print(sprite_socket)

# Receiving pepsi data from client
pepsi_socket = socket2.recv(1024)
pepsi_socket = (pepsi_socket.decode("utf-8")).rsplit("@")
print(pepsi_socket)

# Receiving fanta data from client
fanta_socket = socket2.recv(1024)
fanta_socket = (fanta_socket.decode("utf-8")).rsplit("@")
print(fanta_socket)

# Receiving fantaCherry data from client
fantaCherry_socket = socket2.recv(1024)
fantaCherry_socket = (fantaCherry_socket.decode("utf-8")).rsplit("@")
print(fantaCherry_socket)

# Receiving pepper data from client
pepper_socket = socket2.recv(1024)
pepper_socket = (pepper_socket.decode("utf-8")).rsplit("@")
print(pepper_socket)

# Initialising pygame to be able to play music
pygame.init()


# Function for background music
def play():
    pygame.mixer.music.load("bg_music.mp3")     # Loading File Into Mixer
    pygame.mixer.music.play()   # Playing It In The Whole Device


# Function to stop background music
def stop_music():
    pygame.mixer.music.stop()


# Gui codes
root = Tk()

# Set geometry (width x height)
root.geometry("700x660")

# window title
root.title('Welcome ')

# setting background color to white
root['background'] = 'white'

# Dislaying welcome Image
WelcomePicture = ImageTk.PhotoImage(Image.open('vendingmachinebg.png'))
welcome_label = Label(root, image=WelcomePicture, bg='white')

# heading of welcome Image
head1 = Frame(root)
head1.pack()

# Heading Label of welcome Image
heading1 = Label(head1, text="  Welcome to Nishi's\n Vending Machine", font='Helvetica 30 bold', bg='white',
                 fg='#0f0688', pady=10, padx=10).grid(row=2, column=5)

# Start Button redirects the user to to the main page, with command root.destroy which destroy the welcome page
Start_Button = Button(root, text="Continue", font='Helvetica 30 bold', command=root.destroy, bg='#0f0688', fg='white')
Start_Button.place(x=450, y=550)
welcome_label.pack(side=TOP)

root.mainloop()

# GUI CODE
# Create Object
root = Tk()

# Set geometry (width x height)
root.geometry("1295x675")

# text configuration
root.config(background='#03080c', bd=30, relief=RAISED)

# window title
root.title('Vending Machine')

# Add image file
bg = ImageTk.PhotoImage(file="bg3.png")

# Show image using label
label_background = Label(root, image=bg)
label_background.place(x=0, y=0)

head = Frame(root)
head.pack()

# Heading
heading = Label(head, text='  What would you like to drink?  ', font='Courier 30 bold', bg='#071118', fg='white',
                pady=10, padx=10, bd=10, relief='ridge').pack()


# Play background music Button
play_button = Button(root, text="Play Music", command=play, bg='blue', fg='black')
play_button.place(x=100, y=100)

# Stop background music Button
stop_button = Button(root, text="Stop Music", command=stop_music, bg='blue', fg='black')
stop_button.place(x=200, y=100)

# Creating Frame to Insert Image and Information of Products
frame_image = Frame(root, width=700, height=600, bg='#0f2231', relief='sunken', bd=30)
frame_image.grid_rowconfigure(0, weight=1)

# Inserting Images button to make it more appealing
coca_img = ImageTk.PhotoImage(Image.open('coca12.png'))
coca_btn = Button(frame_image, image=coca_img).grid(row=0, column=0, padx=10, pady=10)
coca_label = Label(frame_image, text="ID: 1\nName: Coke\nPrice: Rs.30\nQuantity:", bg='#0d1d2b', fg='white',
                   font=('digital-7', 12), padx=5, pady=10, justify=LEFT, bd=10).grid(row=0, column=1)
coca_label2 = Label(text=coca_socket[-1], bg='#0d1d2b', fg='white', font=('digital-7', 12)).place(x=245, y=300)

sprite_img = ImageTk.PhotoImage(Image.open('NEWsprite.png'))
sprite_btn = Button(frame_image, image=sprite_img).grid(row=1, column=0, padx=10, pady=10)
sprite_label = Label(frame_image, text="ID: 2\nName: Sprite\nPrice: Rs.40\nQuantity:", bg='#0d1d2b', fg='white',
                     font=('digital-7', 12), padx=5, pady=10, justify=LEFT, bd=10).grid(row=1, column=1)
sprite_label2 = Label(text=sprite_socket[-1], bg='#0d1d2b', fg='white', font=('digital-7', 12)).place(x=478, y=300)

pepsidiet_img = ImageTk.PhotoImage(Image.open('NEWpepsidiet.png'))
pepsidiet_btn = Button(frame_image, image=pepsidiet_img).grid(row=0, column=2, padx=10, pady=10)
pepsi_label = Label(frame_image, text="ID: 3\nName: Pepsi Diet\nPrice: Rs.40\nQuantity:", bg='#0d1d2b', fg='white',
                    font=('digital-7', 12), padx=5, pady=10, justify=LEFT, bd=10).grid(row=0, column=3)
pepsi_label2 = Label(text=pepsi_socket[-1], bg='#0d1d2b', fg='white', font=('digital-7', 12)).place(x=753, y=300)

fanta_img = ImageTk.PhotoImage(Image.open('NEWfanta.png'))
fanta_btn = Button(frame_image, image=fanta_img).grid(row=1, column=2, padx=10, pady=10)
fanta_label = Label(frame_image, text="ID: 4\nName: Fanta\nPrice: Rs.40\nQuantity:", bg='#0d1d2b', fg='white',
                    font=('digital-7', 12), padx=5, pady=10, justify=LEFT, bd=10).grid(row=1, column=3)
fanta_label2 = Label(text=fanta_socket[-1], bg='#0d1d2b', fg='white', font=('digital-7', 12)).place(x=245, y=504)

fantacherry_img = ImageTk.PhotoImage(Image.open('NEWfantacherry.png'))
fantacherry_btn = Button(frame_image, image=fantacherry_img).grid(row=0, column=4, padx=10, pady=10)
fantacherry_label = Label(frame_image, text="ID: 5\nName: Fanta Cherry\nPrice: Rs.30\nQuantity:", bg='#0d1d2b',
                          fg='white', font=('digital-7', 12), padx=5, pady=10, justify=LEFT, bd=10).grid(row=0, column=5)
fantacherry_label2 = Label(text=fantaCherry_socket[-1], bg='#0d1d2b', fg='white', font=('digital-7', 12)).place(x=494, y=504)

pepper_img = ImageTk.PhotoImage(Image.open('NEWpepper.png'))
pepper_btn = Button(frame_image, image=pepper_img).grid(row=1, column=4, padx=10, pady=10)
pepper_label = Label(frame_image, text="ID: 6\nName: Dr.Pepper\nPrice: Rs.50\nQuantity:", bg='#0d1d2b', fg='white',
                     font=('digital-7', 12), padx=5, pady=10, justify=LEFT, bd=10).grid(row=1, column=5)
pepper_label2 = Label(text=pepper_socket[-1], bg='#0d1d2b', fg='white', font=('digital-7', 12)).place(x=763, y=504)

# Packing Image Frame sa as it displays the images and information of products
frame_image.pack(fill=X, expand=True, side=LEFT, padx=20)

# End of Images part


# Function to display barchart
def barchart():
    plt.style.use('bmh')
    df = pd.read_csv('Stock.csv') # Reading the csv file with panda
    # represent name of product in x-axis, and price of products in y-axis
    x = df['Name']
    y = df['Price']
    # Bar chart labeling
    plt.xlabel('Name of Products', fontsize=18)
    plt.ylabel('Price(Rs.)', fontsize=16)
    plt.bar(x, y)
    # displays the bar chart
    plt.show()


# Goodbye Function which dislay an image saying goodbye
def goodbye():
    goodbye_window = Tk()
    # setting window geometry to 600x400
    goodbye_window.geometry("600x400")

    # setting window title to Exit Program
    goodbye_window.title('Exit Program')

    # The user cannot resize the window, as it is set to non-resizable
    goodbye_window.resizable(width=False, height=False)

    # setting background color to black
    goodbye_window['background'] = 'black'

    # goodbye label saying goodbye
    label_goodbye = Label(goodbye_window, text='GOOD-BYE\nWe hope to see you soon...', font='Helvetica 30 bold',
                          fg='white', bg='black')

    # placing the label using x,y
    label_goodbye.place(x=50, y=100)


# error message function for validation of Product ID
def error_message():
    #  setting window geometry
    root.geometry("200x200")
    # Message box is used, to aware the user that he/she did not put a valid Product ID
    messagebox.showwarning("warning", "You have entered a wrong Product ID,\n Please, Try again!")


# message_box function is for the cancel button
def message_box():
    # setting window geometry to 200x200
    root.geometry("200x200")
    # Used as the user did not find the product he/she was looking for
    messagebox.showwarning("warning", "Sorry, we could not provide you with your choice today.\n We hope to see you soon again.\n Have a good day!")
    # Closing the program
    root.destroy()


# The error function is for validation purposes
def error():
    # setting window geometry to 200x200
    root.geometry("200x200")
    # Displaying error message as the user did not fill all the fields
    messagebox.showwarning("warning", "All fields are required!")


# function to warn the client that he/she has not put the required amount of money
def error_cash():
    # setting window geometry to 200x200
    root.geometry("200x200")
    messagebox.showwarning("warning", 'Please enter the required amount of cash!')


# Function for validation of card transaction
def validation_card():
    # getting card number entered by the client and storing it in CardNo1 variable
    CardNo1 = CardNo.get()
    # getting expiry date of the card entered by the client and storing it in ExpiryDate1 variable
    ExpiryDate1 = ExpiryDate.get()
    # getting cvv of the card entered by the client and storing it in cvv1 variable
    cvv1 = cvv.get()
    # Determining if Card number field is blank, that is comparing the user input to the blank space
    if CardNo1 == '':
        error()     # Calls the error function if the CardNo field is blank
        payment_card()      # Calling payment_card function so as the client refill the form until it satisfies the condition, that is he/she do not leave the fields blank
    # Determining if Expiry Date field is blank, that is comparing the user input to the blank space
    elif ExpiryDate1 == '':
        error()     # Calls the error function if the Expiry Date field is blank
        payment_card()      # Calling payment_card function so as the client refill the form until it satisfies the condition, that is he/she do not leave the fields blank
    # Determining if cvv field is blank, that is comparing the user input to the blank space
    elif cvv1 == '':
        error()     # Calls the error function if the cvv field is blank
        payment_card()      # Calling payment_card function so as the client refill the form until it satisfies the condition, that is he/she do not leave the fields blank
    else:
        payment_successful()    # Calling the payment_successful function, meaning the client did fill the form properly and may proceed


# Function for card transaction
def payment_card():
    global CardNo, ExpiryDate, cvv  # declaring CardNo, ExpiryDate, cvv as global variable meaning they can be referenced anywhere in the program
    payment_card_window = Toplevel()    # Toplevel is a window in the application, closing the window will destroy all children widgets placed on that window
    payment_card_window.geometry("400x300")     # set window geometry to 400x300
    payment_card_window.resizable(width=False, height=False)     # setting the window to non-resizable
    payment_card_window.title('Payment ')       # setting window title as Payment
    payment_card_window['background'] = '#99bede'   # setting background color a hexadecimal color value in the shades of blue

    # Creating a frame for Card Transaction
    frame_card = Frame(payment_card_window, width=400, height=300, bg='#99bede', relief='sunken', bd=30)
    frame_card.grid_rowconfigure(0, weight=1)   # configuring the frame
    frame_card.pack()

    # Display total amount
    variable1 = IntVar()    # setting variable1 as an integer variable

    # The label that is the text will be displayed in the frame on Top, the font will be digital-7 of size 13 and of color black
    Label(frame_card, text="Would you like to use Debit or Credit card? ", bg='#99bede', fg='black',
          font=('digital-7', 13)).pack(side=TOP)

    # Radio button used so that the user could select between Debit or Credit card, then placing the button using x, y coordinates
    R1 = Radiobutton(payment_card_window, text="Debit Card", variable=variable1, value=1)
    R1.place(x=40, y=100)
    R2 = Radiobutton(payment_card_window, text="Credit Card", variable=variable1, value=2)
    R2.place(x=250, y=100)

    # Label to display text in the form
    CardNo_text = Label(payment_card_window, text='Enter Card No: ', bg='#99bede', fg='black', font=('digital-7', 11))
    ExpiryDate_text = Label(payment_card_window, text='Enter Expiry Date: ', bg='#99bede', fg='black',
                            font=('digital-7', 11))
    cvv_text = Label(payment_card_window, text='Enter CVV code: ', bg='#99bede', fg='black', font=('digital-7', 11))

    # Placing the Label to display text in the form using x, y coordinates
    CardNo_text.place(x=30, y=150)
    ExpiryDate_text.place(x=30, y=180)
    cvv_text.place(x=30, y=210)

    # Setting CardNo, ExpiryDate, cvv as string variable, that is that the fields only accepts string variable
    CardNo = StringVar()
    ExpiryDate = StringVar()
    cvv = StringVar()

    # Creating entries so as the user has the requires spaces to enter their Card number, Expiry Date of their card number and cvv
    CardNo_entry = Entry(payment_card_window, textvariable=CardNo, width='16', fg='black')
    ExpiryDate_entry = Entry(payment_card_window, textvariable=ExpiryDate, width='16', fg='black')
    cvv_entry = Entry(payment_card_window, textvariable=cvv, width='16', fg='black')

    # Placing the entries
    CardNo_entry.place(x=153, y=153)
    ExpiryDate_entry.place(x=153, y=183)
    cvv_entry.place(x=153, y=213)

    # The enter button proceeds on to the validation process above that is checking if the user fill all the required fields
    # lambda will destroy the window if all fields is full, and proceed on with the program
    # otherwise it will destroy this window(payment_card_window), proceed on to validation_card, if the client did not fill all fields
    # it will show an error message and, the user will have to re-fill the required information asked
    enter_button1 = Button(payment_card_window, text='Done', width='10', height='1',
                           command=lambda: [payment_card_window.destroy(), validation_card()], bg='#2d618e', font=('digital-7', 12))
    enter_button1.place(x=154, y=250)   # placing the button with x,y


# payment_cash is a function for cash transaction
def payment_cash():
    global payment_cash_window, user_cash, TotalAmount
    payment_cash_window = Toplevel()    # setting payment_cash_window as Toplevel
    payment_cash_window.geometry("480x480")     # setting window geometry to 400x480
    payment_cash_window.resizable(width=False, height=False)    # setting window to non-resizable
    payment_cash_window.title('Payment ')   # setting window title as payment
    payment_cash_window['background'] = '#ffd633'   # setting background color

    # Displaying animated .gif file format image
    frameCnt = 12   # setting framecount to 12
    frames = [PhotoImage(file='giphy.gif', format='gif -index %i' % (i)) for i in
              range(frameCnt)]  # Displaying frame per frame

    def update(index):
        global animate  # declaring animate as a global variable, meaning it can be referenced anywhere in the program
        frame = frames[index]
        index += 1  # incrementing index so as to make it more realistic
        if index == frameCnt:   # if index is equal to the frame count, it resets the index to zero, and re-starts the animation
            index = 0
        label.configure(image=frame)
        animate = payment_cash_window.after(100, update, index)

    def stop():
        global animate
        payment_cash_window.after_cancel(animate)

    label = Label(payment_cash_window)
    label.pack()
    payment_cash_window.after(0, update, 0)

    # Displaying Total using a label to the client in the payment_cash_window
    frame_pay_label1 = Label(payment_cash_window, text='Your total amount is Rs.', font="Helvetica 20 bold", bg='white')
    frame_pay_label1.place(x=20, y=10)

    frame_pay_label2 = Label(payment_cash_window, text=TotalAmount, font="Helvetica 20 bold", bg='white')
    frame_pay_label2.place(x=345, y=10)

    # user_cash only accepts Integer data type variable, that is why user_cash is set as IntVar
    user_cash = IntVar()
    # Label that tells the user to enter cash
    msgs_text = Label(payment_cash_window, text="Enter cash: ", bg='white', fg='black', font=('digital-7', 12), padx=5, pady=10)
    # Placing the label using x,y
    msgs_text.place(x=15, y=60)

    # Creating entry for the user to enter cash
    cash_entry = Entry(payment_cash_window, textvariable=user_cash, width='16', fg='black')
    # Placing the entry
    cash_entry.place(x=135, y=69)

    # Change_1 is a function calculate and displays the change to give to the client
    def change1():
        # Getting user input and storing it in the variable Cash
        Cash = user_cash.get()
        if Cash < TotalAmount:  # if the amount of money entered by the user is less than the amount of money he/she need to pay
            error_cash()    # it calls the function error_cash
            payment_cash()      # Then it re-displays the payment_cash window so that the client put the required amount of money
        else:
            Change = Cash - TotalAmount     # else, it calculates the change

            # Labels created to displays the change to the client
            msgs_text1 = Label(payment_cash_window, text="Your Change: Rs.", bg='white', fg='black', font=('digital-7', 12), padx=5, pady=10)
            msgs_text1.place(x=15, y=150)

            msgs_text2 = Label(payment_cash_window, text=Change, bg='white', fg='black', font=('digital-7', 12), padx=5, pady=10)
            msgs_text2.place(x=165, y=150)

            # The enter button2 is used when the user finishes its transaction, it hence stop the animated gif, destroy the payment_cash_window and redirects the client to the payment_successful function
            enter_button2 = Button(payment_cash_window, text='Finish', width='10', height='1',
                                   command=lambda: [stop(), payment_cash_window.destroy(), payment_successful()], bg='red', font=('digital-7', 12))
            enter_button2.place(x=330, y=60)    # Placing the button using x,y
    # The continue button to call the function change1, which is above
    enter_button1 = Button(payment_cash_window, text='Continue', width='10', command=change1, height='1', bg='red',
                           font=('digital-7', 12))
    enter_button1.place(x=330, y=60)     # Placing the button using x,y


# Function which displays that the payment was a success
def payment_successful():
    messagebox.showinfo("Payment", "Payment Successful, Have a good day!\nWe hope to see you soon.")
    root.destroy()      # destroys the main page
    goodbye()   # calls the goodbye function


# Initialising variables
Quantity_sum1 = 0
Quantity_sum2 = 0
Quantity_sum3 = 0
Quantity_sum4 = 0
Quantity_sum5 = 0
Quantity_sum6 = 0
TotalAmount = 0
sum_of_coca = 0
sum_of_sprite = 0
sum_of_pepper = 0
sum_of_fanta = 0
sum_of_fantaCherry = 0
sum_of_pepsi = 0


# The payment Function is the main function of this program
def payment():
    # setting global variables which can be referenced anywhere in the program
    global Quantity_sum1, Quantity_sum2, Quantity_sum3, Quantity_sum4, Quantity_sum5, Quantity_sum6, sum_of_coca, \
        sum_of_sprite, sum_of_pepper, sum_of_fanta, sum_of_fantaCherry, sum_of_pepsi, ProductID_info, Quantity_info, TotalAmount
    if add_button:
        # getting the user input for product ID converting it to integer and storing it to the variable Product_info
        ProductID_info = int(ProductID.get())

        if ProductID_info == 1:
            Quantity_info = int(Quantity_click.get())   # getting the user input for Quantity converting it to integer and storing it to the variable Quantity_info
            Quantity_sum1 = Quantity_sum1 + Quantity_info   # Quantity_sum1 adds the quantity each time the client decides to take another coca
            updated_info = int(coca_socket[-1])     # Converting the Quantity of the csv file sent as a list from the server, as an integer and storing it in the variable updated_info
            updated_info = updated_info - Quantity_sum1     # subtracting the Quantity of the stock.csv with the total quantity entered by the user
            updated_info_str = str(updated_info)    # converting the value from above to string data type
            coca_socket[-1] = updated_info_str  # assigning the updated value the coca_socket using indexing as the quantity is the last column of the csv

            # Displaying label as soon as the user selects Product ID and Quantity
            Label(frame_entry, text=(coca_socket[1]), bg='#132a3d', fg='white').place(x=10, y=10)
            Label(frame_entry, text=('x', Quantity_sum1), bg='#132a3d', fg='white').place(x=70, y=10)
            Label(frame_entry, text='Rs.', bg='#132a3d', fg='white').place(x=100, y=10)
            Label(frame_entry, text=coca_socket[2], bg='#132a3d', fg='white').place(x=120, y=10)
            sum_of_coca = int(coca_socket[2]) * Quantity_sum1   # Calculating sum of coca, by multiplying the price of the product by the quantity selected by the user
            TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper    # Calculating the Total amount
            sum_of_coca_str = str(sum_of_coca)   # Converting the sum_of_coca variable to string and saving it in a new variable
            # Opening Transaction.txt file in append mode
            with open("Transaction.txt", "a+") as file_object:
                # Move read cursor to the start of file.
                file_object.seek(0)
                # If file is not empty then append '\n'
                data = file_object.read(100)
                if len(data) > 0:
                    file_object.write("\n")
                # Append text at the end of file
                file_object.write(str(coca_socket[0]))
                file_object.write(', Coke, ')
                file_object.write('Rs.30, ')
                file_object.write(str(Quantity_click.get()))
                file_object.write(', Rs.')
                file_object.write(sum_of_coca_str)

        elif ProductID_info == 2:
            Quantity_info = int(Quantity_click.get())   # getting the user input for Quantity converting it to integer and storing it to the variable Quantity_info
            Quantity_sum2 = Quantity_sum2 + Quantity_info   # Quantity_sum2 adds the quantity each time the client decides to take another one
            updated_info = int(sprite_socket[-1])    # Converting the Quantity of the csv file sent as a list from the server, as an integer and storing it in the variable updated_info
            updated_info = updated_info - Quantity_sum2     # subtracting the Quantity of the stock.csv with the total quantity entered by the user
            updated_info_str = str(updated_info)    # converting the value from above to string data type
            sprite_socket[-1] = updated_info_str    # assigning the updated value the sprite_socket using indexing as the quantity is the last column of the csv

            # Displaying label as soon as the user selects Product ID and Quantity
            Label(frame_entry, text=(sprite_socket[1]), bg='#132a3d', fg='white', ).place(x=10, y=30)
            Label(frame_entry, text=('x', Quantity_sum2), bg='#132a3d', fg='white', ).place(x=70, y=30)
            Label(frame_entry, text='Rs.', bg='#132a3d', fg='white').place(x=100, y=30)
            Label(frame_entry, text=sprite_socket[2], bg='#132a3d', fg='white').place(x=120, y=30)
            sum_of_sprite = int(sprite_socket[2]) * Quantity_sum2   # Calculating sum of sprite, by multiplying the price of the product by the quantity selected by the user
            TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper    # Calculating the Total amount
            sum_of_sprite_str = str(sum_of_sprite)   # Converting the sum_of_sprite variable to string and saving it in a new variable
            # Opening Transaction.txt file in append mode
            with open("Transaction.txt", "a+") as file_object:
                # Move read cursor to the start of file.
                file_object.seek(0)
                # If file is not empty then append '\n'
                data = file_object.read(100)
                if len(data) > 0:
                    file_object.write("\n")
                # Append text at the end of file
                file_object.write(str(sprite_socket[0]))
                file_object.write(', Sprite, ')
                file_object.write('Rs.40, ')
                file_object.write(str(Quantity_click.get()))
                file_object.write(', Rs.')
                file_object.write(sum_of_sprite_str)

        elif ProductID_info == 3:
            Quantity_info = int(Quantity_click.get())   # getting the user input for Quantity converting it to integer and storing it to the variable Quantity_info
            Quantity_sum3 = Quantity_sum3 + Quantity_info   # Quantity_sum3 adds the quantity each time the client decides to take another one
            updated_info = int(pepsi_socket[-1])     # Converting the Quantity of the csv file sent as a list from the server, as an integer and storing it in the variable updated_info
            updated_info = updated_info - Quantity_sum3      # subtracting the Quantity of the stock.csv with the total quantity entered by the user
            updated_info_str = str(updated_info)    # converting the value from above to string data type
            pepsi_socket[-1] = updated_info_str     # assigning the updated value the pepsi_socket using indexing as the quantity is the last column of the csv

            # Displaying label as soon as the user selects Product ID and Quantity
            Label(frame_entry, text=(pepsi_socket[1]), bg='#132a3d', fg='white', ).place(x=10, y=50)
            Label(frame_entry, text=('x', Quantity_sum3), bg='#132a3d', fg='white', ).place(x=70, y=50)
            Label(frame_entry, text='Rs.', bg='#132a3d', fg='white').place(x=100, y=50)
            Label(frame_entry, text=pepsi_socket[2], bg='#132a3d', fg='white').place(x=120, y=50)
            sum_of_pepsi = int(pepsi_socket[2]) * Quantity_sum3     # Calculating sum of pepsi, by multiplying the price of the product by the quantity selected by the user
            TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper    # Calculating the Total amount
            sum_of_pepsi_str = str(sum_of_pepsi)     # Converting the sum_of_pepsi variable to string and saving it in a new variable
            # Opening Transaction.txt file in append mode
            with open("Transaction.txt", "a+") as file_object:
                # Move read cursor to the start of file.
                file_object.seek(0)
                # If file is not empty then append '\n'
                data = file_object.read(100)
                if len(data) > 0:
                    file_object.write("\n")
                # Append text at the end of file
                file_object.write(str(pepsi_socket[0]))
                file_object.write(', Pepsi, ')
                file_object.write('Rs.40, ')
                file_object.write(str(Quantity_click.get()))
                file_object.write(', Rs.')
                file_object.write(sum_of_pepsi_str)

        elif ProductID_info == 4:
            Quantity_info = int(Quantity_click.get())   # getting the user input for Quantity converting it to integer and storing it to the variable Quantity_info
            Quantity_sum4 = Quantity_sum4 + Quantity_info   # Quantity_sum4 adds the quantity each time the client decides to take another one
            updated_info = int(fanta_socket[-1])     # Converting the Quantity of the csv file sent as a list from the server, as an integer and storing it in the variable updated_info
            updated_info = updated_info - Quantity_sum4      # subtracting the Quantity of the stock.csv with the total quantity entered by the user
            updated_info_str = str(updated_info)    # converting the value from above to string data type
            fanta_socket[-1] = updated_info_str # assigning the updated value the fanta_socket using indexing as the quantity is the last column of the csv

            # Displaying label as soon as the user selects Product ID and Quantity
            Label(frame_entry, text=(fanta_socket[1]), bg='#132a3d', fg='white', ).place(x=150, y=10)
            Label(frame_entry, text=('x', Quantity_sum4), bg='#132a3d', fg='white', ).place(x=225, y=10)
            Label(frame_entry, text='Rs.', bg='#132a3d', fg='white').place(x=245, y=10)
            Label(frame_entry, text=fanta_socket[2], bg='#132a3d', fg='white').place(x=265, y=10)
            sum_of_fanta = int(fanta_socket[2]) * Quantity_sum4     # Calculating sum of fanta, by multiplying the price of the product by the quantity selected by the user
            TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper    # Calculating the Total amount
            sum_of_fanta_str = str(sum_of_fanta)     # Converting the sum_of_fanta variable to string and saving it in a new variable
            # Opening Transaction.txt file in append mode
            with open("Transaction.txt", "a+") as file_object:
                # Move read cursor to the start of file.
                file_object.seek(0)
                # If file is not empty then append '\n'
                data = file_object.read(100)
                if len(data) > 0:
                    file_object.write("\n")
                # Append text at the end of file
                file_object.write(str(fanta_socket[0]))
                file_object.write(', Fanta, ')
                file_object.write('Rs.40, ')
                file_object.write(str(Quantity_click.get()))
                file_object.write(', Rs.')
                file_object.write(sum_of_fanta_str)

        elif ProductID_info == 5:
            Quantity_info = int(Quantity_click.get())   # getting the user input for Quantity converting it to integer and storing it to the variable Quantity_info
            Quantity_sum5 = Quantity_sum5 + Quantity_info   # Quantity_sum5 adds the quantity each time the client decides to take another one
            updated_info = int(fantaCherry_socket[-1])   # Converting the Quantity of the csv file sent as a list from the server, as an integer and storing it in the variable updated_info
            updated_info = updated_info - Quantity_sum5      # subtracting the Quantity of the stock.csv with the total quantity entered by the user
            updated_info_str = str(updated_info)    # converting the value from above to string data type
            fantaCherry_socket[-1] = updated_info_str   # assigning the updated value the fantaCherry_socket using indexing as the quantity is the last column of the csv

            # Displaying label as soon as the user selects Product ID and Quantity
            Label(frame_entry, text=(fantaCherry_socket[1]), bg='#132a3d', fg='white', ).place(x=150, y=30)
            Label(frame_entry, text=('x', Quantity_sum5), bg='#132a3d', fg='white', ).place(x=225, y=30)
            Label(frame_entry, text='Rs.', bg='#132a3d', fg='white').place(x=245, y=30)
            Label(frame_entry, text=fantaCherry_socket[2], bg='#132a3d', fg='white').place(x=265, y=30)
            sum_of_fantaCherry = int(fantaCherry_socket[2]) * Quantity_sum5     # Calculating sum of fantaCherry, by multiplying the price of the product by the quantity selected by the user
            TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper    # Calculating the Total amount
            sum_of_fantaCherry_str = str(sum_of_fantaCherry)    # Converting the sum_of_fantaCherry variable to string and saving it in a new variable
            # Opening Transaction.txt file in append mode
            with open("Transaction.txt", "a+") as file_object:
                # Move read cursor to the start of file.
                file_object.seek(0)
                # If file is not empty then append '\n'
                data = file_object.read(100)
                if len(data) > 0:
                    file_object.write("\n")
                # Append text at the end of file
                file_object.write(str(fantaCherry_socket[0]))
                file_object.write(', Fanta Cherry, ')
                file_object.write('Rs.30, ')
                file_object.write(str(Quantity_click.get()))
                file_object.write(', Rs.')
                file_object.write(sum_of_fantaCherry_str)

        elif ProductID_info == 6:
            Quantity_info = int(Quantity_click.get())   # getting the user input for Quantity converting it to integer and storing it to the variable Quantity_info
            Quantity_sum6 = Quantity_sum6 + Quantity_info   # Quantity_sum6 adds the quantity each time the client decides to take another one
            updated_info = int(pepper_socket[-1])    # Converting the Quantity of the csv file sent as a list from the server, as an integer and storing it in the variable updated_info
            updated_info = updated_info - Quantity_sum6      # subtracting the Quantity of the stock.csv with the total quantity entered by the user
            updated_info_str = str(updated_info)    # converting the value from above to string data type
            pepper_socket[-1] = updated_info_str    # assigning the updated value the pepper_socket using indexing as the quantity is the last column of the csv

            # Displaying label as soon as the user selects Product ID and Quantity
            Label(frame_entry, text=(pepper_socket[1]), bg='#132a3d', fg='white', ).place(x=150, y=50)
            Label(frame_entry, text=('x', Quantity_sum6), bg='#132a3d', fg='white', ).place(x=225, y=50)
            Label(frame_entry, text='Rs.', bg='#132a3d', fg='white').place(x=245, y=50)
            Label(frame_entry, text=pepper_socket[2], bg='#132a3d', fg='white').place(x=265, y=50)
            sum_of_pepper = int(pepper_socket[2]) * Quantity_sum6   # Calculating sum of pepper, by multiplying the price of the product by the quantity selected by the user
            TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper
            sum_of_pepper_str = str(sum_of_pepper)
            # Opening Transaction.txt file in append mode
            with open("Transaction.txt", "a+") as file_object:
                # Move read cursor to the start of file.
                file_object.seek(0)
                # If file is not empty then append '\n'
                data = file_object.read(100)
                if len(data) > 0:
                    file_object.write("\n")
                # Append text at the end of file
                file_object.write(str(pepper_socket[0]))
                file_object.write(', Dr. Pepper, ')
                file_object.write('Rs.50, ')
                file_object.write(str(Quantity_click.get()))
                file_object.write(', Rs.')
                file_object.write(sum_of_pepper_str)
        else:
            error_message()     # Calling error_message function, if the Product ID is not equal to 1 or 2 or 3 or 4 or 5 or 6

        Quantity_click.set(options[0])  # setting quantity drop-down button to 0, when the user press add another button
        ProductID_entry.delete(0, END)  # setting Product ID entry to 0, when the user press add another button
        # Creating label to display the client total and keep updating it
        Label(frame_entry, text='Total:', font='Helvetica 12 bold', bg='#132a3d', fg='white').place(x=80, y=70)
        Label(frame_entry, text='Rs.', font='Helvetica 12 bold', bg='#132a3d', fg='white').place(x=140, y=70)
        Label(frame_entry, text=TotalAmount, font='Helvetica 12 bold underline', bg='#132a3d', fg='white').place(x=170, y=70)


# receipt function displays the receipt after the user is done with its selection, and press finish and pay
def receipt():
    # setting global variables
    global Quantity_sum1, Quantity_sum2, Quantity_sum3, Quantity_sum4, Quantity_sum5, Quantity_sum6, sum_of_coca, \
        sum_of_sprite, sum_of_pepper, sum_of_fanta, sum_of_fantaCherry, sum_of_pepsi, ProductID_info, Quantity_info, TotalAmount

    receipt_window = Toplevel()     # setting receipt_window as Toplevel
    receipt_window.geometry("500x650")      # setting window geometry to 500x650
    receipt_window.resizable(width=False, height=False)     # setting the window to non-resizable
    receipt_window.title('Receipt ')    # setting window title as receipt
    # Creating Label for receipt as text
    Label(receipt_window, text='Receipt', font='Helvetica 50 bold', bg='#ffe6e6').place(x=100, y=70)
    # Creating Label to display today's date
    Label(receipt_window, text=f"{datetime.datetime.now():%a, %b %d %Y}", fg="black", font=('Helvetica 20 bold')).place(x=260, y=10)

# Displaying the label below if Quantitysum1 which is for coca is greater than 0
    if Quantity_sum1 > 0:
        Label(receipt_window, text=coca_socket[1], fg="black", font=('Helvetica 20')).place(x=20, y=200)
        Label(receipt_window, text=('x', Quantity_sum1), fg='black', font=('Helvetica 20')).place(x=280, y=200)
        Label(receipt_window, text='Rs.', fg='black', font=('Helvetica 20')).place(x=360, y=200)
        Label(receipt_window, text=coca_socket[2], fg='black', font=('Helvetica 20')).place(x=420, y=200)
        sum_of_coca = int(coca_socket[2]) * Quantity_sum1   # Calculating sum of coca, by multiplying the price of the product by the quantity selected by the user
        TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper    # Calculating Total amount

# Displaying the label below if Quantitysum2 which is for sprite is greater than 0
    if Quantity_sum2 > 0:
        Label(receipt_window, text=(sprite_socket[1]), fg='black', font=('Helvetica 20')).place(x=20, y=250)
        Label(receipt_window, text=('x', Quantity_sum2), fg='black', font=('Helvetica 20')).place(x=280, y=250)
        Label(receipt_window, text='Rs.', fg='black', font=('Helvetica 20')).place(x=360, y=250)
        Label(receipt_window, text=sprite_socket[2], fg='black', font=('Helvetica 20')).place(x=420, y=250)
        sum_of_sprite = int(sprite_socket[2]) * Quantity_sum2   # Calculating sum of sprite, by multiplying the price of the product by the quantity selected by the user
        TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper      # Calculating Total amount

# Displaying the label below if Quantitysum3 which is for pepsi is greater than 0
    if Quantity_sum3 > 0:
        Label(receipt_window, text=(pepsi_socket[1]), fg='black', font=('Helvetica 20')).place(x=20, y=300)
        Label(receipt_window, text=('x', Quantity_sum3), fg='black', font=('Helvetica 20')).place(x=280, y=300)
        Label(receipt_window, text='Rs.', fg='black', font=('Helvetica 20')).place(x=360, y=300)
        Label(receipt_window, text=pepsi_socket[2], fg='black', font=('Helvetica 20')).place(x=420, y=300)
        sum_of_pepsi = int(pepsi_socket[2]) * Quantity_sum3 # Calculating sum of pepsi, by multiplying the price of the product by the quantity selected by the user
        TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper    # Calculating Total amount

# Displaying the label below if Quantitysum4 which is for fanta is greater than 0
    if Quantity_sum4 > 0:
        Label(receipt_window, text=(fanta_socket[1]), fg='black', font=('Helvetica 20')).place(x=20, y=350)
        Label(receipt_window, text=('x', Quantity_sum4), fg='black', font=('Helvetica 20')).place(x=280, y=350)
        Label(receipt_window, text='Rs.', fg='black', font=('Helvetica 20')).place(x=360, y=350)
        Label(receipt_window, text=fanta_socket[2], fg='black', font=('Helvetica 20')).place(x=420, y=350)
        sum_of_fanta = int(fanta_socket[2]) * Quantity_sum4 # Calculating sum of fanta, by multiplying the price of the product by the quantity selected by the user
        TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper    # Calculating Total amount

# Displaying the label below if Quantitysum5 which is for fantaCherry is greater than 0
    if Quantity_sum5 > 0:
        Label(receipt_window, text=(fantaCherry_socket[1]), fg='black', font=('Helvetica 20')).place(x=20, y=400)
        Label(receipt_window, text=('x', Quantity_sum5), fg='black', font=('Helvetica 20')).place(x=280, y=400)
        Label(receipt_window, text='Rs.', fg='black', font=('Helvetica 20')).place(x=360, y=400)
        Label(receipt_window, text=fantaCherry_socket[2], fg='black', font=('Helvetica 20')).place(x=420, y=400)
        sum_of_fantaCherry = int(fantaCherry_socket[2]) * Quantity_sum5 # Calculating sum of fanatCherry, by multiplying the price of the product by the quantity selected by the user
        TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper    # Calculating Total amount

# Displaying the label below if Quantitysum6 which is for dr.pepper is greater than 0
    if Quantity_sum6 > 0:
        Label(receipt_window, text=(pepper_socket[1]), fg='black', font=('Helvetica 20')).place(x=20, y=450)
        Label(receipt_window, text=('x', Quantity_sum6), fg='black', font=('Helvetica 20')).place(x=280, y=450)
        Label(receipt_window, text='Rs.', fg='black', font=('Helvetica 20')).place(x=360, y=450)
        Label(receipt_window, text=pepper_socket[2], fg='black', font=('Helvetica 20')).place(x=420, y=450)
        sum_of_pepper = int(pepper_socket[2]) * Quantity_sum6   # Calculating sum of dr.pepper, by multiplying the price of the product by the quantity selected by the user
        TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper    # Calculating Total amount

    # Label displaying the final total amount in the format of a receipt
    Label(receipt_window, text='Total:', fg='black', font=('Helvetica 30')).place(x=20, y=500)
    Label(receipt_window, text='Rs.', fg='black', font=('Helvetica 30')).place(x=335, y=500)
    Label(receipt_window, text=TotalAmount, fg='black', font=('Helvetica 30 bold underline')).place(x=400, y=500)
    # The button has command to destroy the receipt_window and proceed on to finish_payment function
    Button_payment = Button(receipt_window, text='Proceed to Payment', width=20, height=3, relief='raised', bg='#ffe6e6', command=lambda: [receipt_window.destroy(), finish_payment()])
    Button_payment.place(x=176, y=550)


# The finish payment function allows the user to select which payment method he/she wants ( card or cash ) to use
def finish_payment():
    global TotalAmount  # setting totalamount variable as a global variable
    payment_window = Tk()
    payment_window.geometry("400x250")      # setting payment_window geometry 400x250
    payment_window.resizable(height=False, width=False)     # the window is non-resizable
    payment_window.title('Payment ')    # the window title is Payment
    TotalAmount = sum_of_coca + sum_of_pepsi + sum_of_fanta + sum_of_fantaCherry + sum_of_sprite + sum_of_pepper # Calculating Total Amount

    # Creating a frame to allow the user to chose payment method
    frame_pay = Frame(payment_window, width=600, height=150, bg='#99bede', relief='sunken', bd=30)
    frame_pay.grid_rowconfigure(0, weight=1)    # configuring the frame
    frame_pay.pack()
    # Label to display the total and asking the client how he/she wants to proceed with the payment
    frame_pay_label1 = Label(frame_pay, text='Your total amount is Rs.', font="50", bg='#99bede')
    frame_pay_label1.place(x=5, y=9)
    frame_pay_label2 = Label(frame_pay, text=TotalAmount, font="50", bg='#99bede')
    frame_pay_label2.place(x=170, y=9)
    frame_pay_label3 = Label(frame_pay, text='How would you like to proceed with the payment?', font="50", bg='#99bede')
    frame_pay_label3.place(x=5, y=50)

    # Button for cash transaction with the command to destroy this window and call the payment_cash function
    cash_button = Button(payment_window, text='Cash', width='45', height='2', bg='#2d618e', command=lambda: [payment_window.destroy(), payment_cash()], font=('digital-7', 12))
    cash_button.pack()

    # Button for card transaction with the command to destroy this window and call the payment_card function
    card_button = Button(payment_window, text='Card', width='45', height='2', bg='#1f4462', command=lambda: [payment_window.destroy(), payment_card()], font=('digital-7', 12))
    card_button.pack()


# Click button function is for the buttons below, used mainly to enter Product ID
def click_button(event):
    if ProductID_entry:
        a = event.widget
        text = a['text']
        print(text)
        ProductID_entry.insert(END, text)


# function to clear one digit
def clear():
    if ProductID_entry:
        num = ProductID_entry.get()  # variable clicked by by user
        num = num[0:len(num) - 1]  # Decrementing length by 1, using string manipulation
        ProductID_entry.delete(0, END)
        ProductID_entry.insert(0, num)


# Entry part;

# Creating frame to allow the client to enter product ID and quantity of his/her choice
frame_entry = Frame(root, width=450, height=400, bg='#132a3d', relief='raised', bd=30)
frame_entry.grid_rowconfigure(0, weight=1)
frame_entry.pack(fill=Y, expand=True, side=RIGHT, padx=20, pady=20)

# Labels asking the client to enter product ID and quantity of his/her choice
ProductID_text = Label(frame_entry, text='Enter Product ID: ', bg='#132a3d', fg='white', font=('digital-7', 15))
Quantity_text = Label(frame_entry, text='Quantity: ', bg='#132a3d', fg='white', font=('digital-7', 15))

# Drop down button
options = ["0", "1", "2", "3", "4", "5"]

Quantity_click = IntVar()   # Accepts only integer variable
Quantity_click.set(options[0])  # is set to 0

# The button is placed in frame_entry, allows the user to select between 0 to 5 as quantity
drop = OptionMenu(frame_entry, Quantity_click, *options)
drop.place(x=105, y=155)

# Placing text using x,y
ProductID_text.place(x=10, y=120)
Quantity_text.place(x=10, y=154)

# Creating and placing entry for the Product ID
ProductID = StringVar()
ProductID_entry = Entry(frame_entry, textvariable=ProductID, width='4', fg='black')
ProductID_entry.place(x=180, y=127)


# Buttons for the Vending Machine, so as the user can add the Product ID of its choice
zero = Button(frame_entry, text='0', width=5, height=2, relief='raised', bg='#295981', activeforeground='plum')
zero.place(x=60, y=210)

one = Button(frame_entry, text='1', width=5, height=2, relief='raised', bg='#295981', activeforeground='plum')
one.place(x=120, y=210)

two = Button(frame_entry, text='2', width=5, height=2, relief='raised', bg='#295981', activeforeground='plum')
two.place(x=180, y=210)

three = Button(frame_entry, text='3', width=5, height=2, relief='raised', bg='#295981', activeforeground='plum')
three.place(x=60, y=260)

four = Button(frame_entry, text='4', width=5, height=2, relief='raised', bg='#295981', activeforeground='plum')
four.place(x=120, y=260)

five = Button(frame_entry, text='5', width=5, height=2, relief='raised', bg='#295981', activeforeground='plum')
five.place(x=180, y=260)

six = Button(frame_entry, text='6', width=5, height=2, relief='raised', bg='#295981', activeforeground='plum')
six.place(x=60, y=310)

seven = Button(frame_entry, text='7', width=5, height=2, relief='raised', bg='#295981', activeforeground='plum')
seven.place(x=120, y=310)

eight = Button(frame_entry, text='8', width=5, height=2, relief='raised', bg='#295981', activeforeground='plum')
eight.place(x=180, y=310)

nine = Button(frame_entry, text='9', width=5, height=2, relief='raised', bg='#295981', activeforeground='plum')
nine.place(x=60, y=360)

clear = Button(frame_entry, text='Clear', width=14, height=2, relief='raised', bg='#234c6f', activeforeground='plum',command=clear)
clear.place(x=120, y=360)

# Binding Buttons
one.bind('<Button>', click_button)
two.bind('<Button>', click_button)
three.bind('<Button>', click_button)
four.bind('<Button>', click_button)
five.bind('<Button>', click_button)
six.bind('<Button>', click_button)
seven.bind('<Button>', click_button)
eight.bind('<Button>', click_button)
nine.bind('<Button>', click_button)
zero.bind('<Button>', click_button)

# These buttons are found in the frame_entry
# Buttons to add, finish&pay, quit and Cancel order
# Buttons are in a dark blue shades and each of width 10 and height 1, with font digital-7 of size 12
# Each has a specific command which calls the above function
add_button = Button(frame_entry, text='Add to cart', width='10', height='1', command=payment, bg='#3573a6', font=('digital-7', 12))
add_button.place(x=30, y=420)

cancel_button = Button(frame_entry, text='Cancel', width='10', height='1', command=message_box, bg='#3573a6', font=('digital-7', 12))
cancel_button.place(x=160, y=420)

finish_button = Button(frame_entry, text='Finish & Pay', width='10', height='1', command=receipt, bg='#3573a6', font=('digital-7', 12))
finish_button.place(x=160, y=465)

Bar_Chart_Button = Button(frame_entry, text='Reports', width='10', height='1', command=barchart, bg='#3573a6', font=('digital-7', 12))
Bar_Chart_Button.place(x=30, y=465)

root.mainloop()


# Sending coca data to the server
coca_str = "@".join(coca_socket)
print(coca_str)
socket2.send(bytes(coca_str, "utf-8"))

# Sending sprite data to the server
sprite_str = "@".join(sprite_socket)
print(sprite_str)
socket2.send(bytes(sprite_str, "utf-8"))

# Sending pepsi data to the server
pepsi_str = "@".join(pepsi_socket)
print(pepsi_str)
socket2.send(bytes(pepsi_str, "utf-8"))

# Sending fanta data to the server
fanta_str = "@".join(fanta_socket)
print(fanta_str)
socket2.send(bytes(fanta_str, "utf-8"))

# Sending fantaCherry data to the server
fantaCherry_str = "@".join(fantaCherry_socket)
print(fantaCherry_str)
socket2.send(bytes(fantaCherry_str, "utf-8"))

# Sending pepper data to the server
pepper_str = "@".join(pepper_socket)
print(pepper_str)
socket2.send(bytes(pepper_str, "utf-8"))
